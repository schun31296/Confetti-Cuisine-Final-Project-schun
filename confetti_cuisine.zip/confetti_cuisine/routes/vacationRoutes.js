"use strict";

const router = require("express").Router(),
    vacationsController = require("../controllers/vacationsController");

router.get("", vacationsController.index, vacationsController.indexView);
router.get("/new", requireLogin, vacationsController.new);
router.post("/create", vacationsController.create, vacationsController.redirectView);
router.get("/:id/edit", requireLogin, vacationsController.edit);
router.put("/:id/update", vacationsController.update, vacationsController.redirectView);
router.get("/:id", vacationsController.show, vacationsController.showView);
router.delete("/:id/delete", requireLogin, vacationsController.delete, vacationsController.redirectView);

function requireLogin(req, res, next) {
    if (!!req.session && !!req.session.user) {
        next();
    } else {
        res.redirect('/');
    }
}

module.exports = router;
